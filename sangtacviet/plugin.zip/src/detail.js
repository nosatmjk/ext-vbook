function execute(url) {
    let response = fetch(url + '/');
    if (response.ok) {
        let doc = response.html();
        let author = doc.select("i.cap h2").text() || doc.html().match(/Tác giả:.*?\s+(.*?)\s*</)[1];
        let des = doc.select("#book-sumary").html();
        let cover = doc.select("#thumb-prop").attr("src");
        
        return Response.success({
            name: doc.select("#book_name2").text(),
            cover: cover,
            author: author || 'Ẩn danh',
            description: des,
            detail: "Nguồn: " + doc.select(".rd-tag").first().text() + "<br>Tên gốc: " + doc.select("#oriname").text(),
            ongoing: doc.select("#bookstatus").text().indexOf("Còn tiếp") >= 0,
            host: "https://sangtacviet.pro"
        });
    }
    return null;
}