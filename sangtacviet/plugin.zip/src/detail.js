function execute(url) {
    if (url.slice(-1) !== "/") url = url + "/";
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        // Bóc tách tên tác giả bằng Regex từ chuỗi HTML
        let authorMatch = doc.html().match(/Tác giả:.*?(\w.*?)<\//);
        let author = authorMatch ? authorMatch[1].trim() : 'Chưa rõ';
        
        let des = doc.select(".blk:has(.fa-water) .blk-body").html();
        
        return Response.success({
            name: doc.select("#book_name2").text().trim(),
            cover: doc.select(".container:has(#book_name2) img").first().attr("src"),
            author: author,
            description: des,
            detail: "Nguồn: " + doc.select("#oriname").text(),
            ongoing: true,
            host: "https://sangtacviet.pro"
        });
    }
    return null;
}