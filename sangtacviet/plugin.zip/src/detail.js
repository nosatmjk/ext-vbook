function execute(url) {
    // Đảm bảo URL có dấu / ở cuối
    if (!url.endsWith('/')) url = url + '/';
    
    let response = fetch(url);
    if (!response.ok) return null;
    
    let doc = response.html();
    
    // Lấy tên truyện
    let name = doc.select("#book_name2").first().text();
    name = capitalize(name);
    
    // Lấy ảnh bìa
    let cover = doc.select(".container:has(#book_name2) img").first().attr("src");
    if (cover.startsWith('//')) cover = 'https:' + cover;
    
    // Lấy tác giả
    let author = 'Unknown';
    let authorMatch = doc.html().match(/Tác giả:.*?\s+(.*?)\s*</);
    if (authorMatch) author = authorMatch[1];
    
    // Lấy mô tả
    let description = doc.select("#book-sumary").html();
    
    // Lấy thông tin chi tiết
    let oriName = doc.select("#oriname").text();
    let hanViet = doc.select(".blk-body:contains(Hán việt)").text().replace('Hán việt:', '').trim();
    let category = doc.select(".blk-body:contains(Thể loại)").text().replace('Thể loại:', '').trim();
    let source = doc.select(".blk-body:contains(Nguồn truyện)").text().replace('Nguồn truyện:', '').trim();
    
    let detail = `Tên gốc: ${oriName}<br>Hán việt: ${hanViet}<br>Thể loại: ${category}<br>Nguồn: ${source}`;
    
    return Response.success({
        name: name,
        cover: cover,
        host: "https://sangtacviet.pro",
        author: author,
        description: description,
        detail: detail,
        ongoing: true // Mặc định, có thể check sau
    });
}

function capitalize(sentence) {
    if (!sentence) return '';
    return sentence.split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}