function execute(url) {
    if (url.slice(-1) !== "/") url = url + "/";
    let browser = Engine.newBrowser();
    browser.launch(url, 5000); 

    let retry = 0;
    while (retry < 10) {
        let doc = browser.html();
        if (doc.select("#chaptercontainerinner").length > 0) {
            // Lệnh quan trọng: Cuộn tới danh sách chương để STV load dữ liệu
            browser.callJs("document.getElementById('chaptercontainerinner').scrollIntoView();", 500);
            break;
        }
        sleep(1000);
        retry++;
    }

    let list = [];
    let el = browser.html().select("a.listchapitem");
    
    for (let i = 0; i < el.length; i++) {
        list.push({
            name: el.get(i).text(),
            url: url + "----/----" + i // Gửi index để chap.js click đúng chương
        });
    }

    browser.close();
    return list.length > 0 ? Response.success(list) : Response.error("Không lấy được mục lục");
}