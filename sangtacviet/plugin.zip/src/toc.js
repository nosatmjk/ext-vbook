function execute(url) {
    if (!url.endsWith('/')) url = url + '/';
    
    // Dùng fetch trước để lấy HTML nhanh
    let response = fetch(url);
    if (!response.ok) return null;
    
    // Kiểm tra xem có cần dùng browser không
    let doc = response.html();
    if (doc.select("#chaptercontainerinner a.listchapitem").length > 0) {
        // Đã có sẵn danh sách chương trong HTML
        return parseChapters(doc, url);
    } else {
        // Cần dùng browser để load động
        return loadChaptersWithBrowser(url);
    }
}

function parseChapters(doc, baseUrl) {
    let chapters = doc.select("#chaptercontainerinner a.listchapitem");
    if (chapters.length === 0) return null;
    
    let list = [];
    for (let i = 0; i < chapters.length; i++) {
        let chap = chapters.get(i);
        let chapName = chap.text();
        
        // Xử lý URL đặc biệt của STV
        // Format: /truyen/faloo/550081/3614/
        let chapUrl = baseUrl + "----/----" + i;
        
        list.push({
            name: chapName,
            url: chapUrl
        });
    }
    
    return Response.success(list);
}

function loadChaptersWithBrowser(url) {
    let browser = Engine.newBrowser();
    browser.launchAsync(url);
    
    let maxRetry = 8;
    let retry = 0;
    let chapters = null;
    
    while (retry < maxRetry) {
        sleep(1500);
        let doc = browser.html();
        
        if (doc.select("#chaptercontainerinner").length > 0) {
            browser.callJs("document.getElementById('chaptercontainerinner').scrollIntoView();", 500);
        }
        
        chapters = doc.select("#chaptercontainerinner a.listchapitem");
        if (chapters.length > 0) {
            break;
        }
        retry++;
    }
    
    browser.close();
    
    if (!chapters || chapters.length === 0) return null;
    
    let list = [];
    for (let i = 0; i < chapters.length; i++) {
        list.push({
            name: chapters.get(i).text(),
            url: url + "----/----" + i
        });
    }
    
    return Response.success(list);
}