function execute(url) {
    if (url.slice(-1) !== "/") url = url + "/";
    let browser = Engine.newBrowser();
    browser.launchAsync(url);
    
    var retry = 0;
    var el = [];
    while (retry < 15) {
        sleep(1000);
        let doc = browser.html();
        el = doc.select("a.listchapitem");
        if (el.length > 0) {
            // Cuộn xuống để STV load hết chương nếu là danh sách dài
            browser.callJs("window.scrollTo(0, document.body.scrollHeight/2);", 100);
            break;
        }
        retry++;
    }

    let list = [];
    for (let i = 0; i < el.length; i++) {
        let e = el.get(i);
        list.push({
            name: e.text().trim(),
            url: url + "----/----" + i
        });
    }
    browser.close();
    return list.length > 0 ? Response.success(list) : Response.error("Không tải được mục lục STV");
}