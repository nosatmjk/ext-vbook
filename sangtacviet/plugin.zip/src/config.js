// Cấu hình chung cho extension
let BASE_URL = "https://sangtacviet.pro";
let GIT_STV = "https://raw.githubusercontent.com/sangtacviet/sangtacviet.github.io/main/update.json";

// Lấy domain hiện tại từ GitHub
let URL_STV = BASE_URL;
try {
    let response = fetch(GIT_STV);
    if (response.ok) {
        let json = response.json();
        if (json.domain) {
            URL_STV = json.domain;
        }
    }
} catch (error) {
    console.log("Không thể lấy domain từ GitHub, dùng mặc định");
}

// Cho phép ghi đè từ bên ngoài nếu cần
try {
    if (typeof CONFIG_URL !== 'undefined') {
        BASE_URL = CONFIG_URL;
        URL_STV = CONFIG_URL;
    }
} catch (error) {}