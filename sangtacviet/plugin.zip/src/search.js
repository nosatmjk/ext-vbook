load("config.js");

function execute(key, page) {
    if (!page) page = '1';
    
    let apiUrl = URL_STV + "/io/searchtp/searchBooks?find=&findinname=" + encodeURIComponent(key) + "&minc=0&p=" + page + "&tag=";
    let response = fetch(apiUrl);
    
    if (response.ok) {
        let doc = response.html();
        let next = doc.select(".pagination li.active + li").text();
        let books = doc.select("a.booksearch");
        let data = [];
        
        books.forEach(book => {
            let cover = book.select("img").first().attr("src");
            if (cover.startsWith('//')) cover = 'https:' + cover;
            
            data.push({
                name: book.select(".searchbooktitle").first().text(),
                link: book.select("a").first().attr("href"),
                cover: cover,
                description: book.select("div > span.searchtag").last().text(),
                host: URL_STV
            });
        });
        
        return Response.success(data, next);
    }
    return null;
}