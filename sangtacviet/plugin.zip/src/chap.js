load("config.js");

function execute(url) {
    // URL có dạng: /?bookid=XXX&c=YYY&h=ZZZ
    // Gọi API local hoặc trực tiếp
    
    let fullUrl = URL_STV + url;
    let response = fetch(fullUrl);
    
    if (!response.ok) {
        // Thử với BASE_URL nếu URL_STV không hoạt động
        fullUrl = BASE_URL + url;
        response = fetch(fullUrl);
        if (!response.ok) {
            return Response.error("HTTP SERVER không hoạt động");
        }
    }
    
    try {
        let text = response.text();
        
        // Tìm JSON trong response (dạng {...})
        let match = text.match(/\{[\s\S]*\}/);
        if (!match) return Response.error("Không tìm thấy dữ liệu");
        
        let json = JSON.parse(match[0]);
        
        if (!json.data) {
            return Response.error(json.err || "Không có nội dung");
        }
        
        // Xử lý nội dung
        let content = json.data;
        
        // Xử lý các thẻ đặc biệt
        content = content.replace(/<i([^>]*)t='(.*?)'([^>]*)>(.*?)<\/i>/g, `<i$1t='$2'$3>$2</i>`);
        
        // Xử lý xuống dòng
        content = content.replace(/\n\t/g, "</p><p>\t");
        
        // Làm sạch HTML
        content = content
            .replace(/<p>/g, '<p>')
            .replace(/&lt;p&gt;/g, '<p>')
            .replace(/&lt;\/p&gt;/g, '</p>')
            .replace(/<br>/g, '<br>');
        
        return Response.success(content);
        
    } catch (error) {
        console.log("Lỗi parse chap: " + error);
        return Response.error("Lỗi xử lý nội dung");
    }
}