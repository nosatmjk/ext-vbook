function execute(url) {
    let urlPart = url.split("----/----");
    let browser = Engine.newBrowser();
    browser.launchAsync(urlPart[0]);

    // Chờ và click vào đúng chương dựa trên index
    var retry = 0;
    while (retry < 10) {
        sleep(1200);
        let doc = browser.html();
        if (doc.select("a.listchapitem").length > 0) {
            browser.callJs("document.getElementsByClassName('listchapitem')[" + urlPart[1] + "].click();", 500);
            break;
        }
        retry++;
    }

    // Lấy nội dung
    var content = "";
    retry = 0;
    while (retry < 10) {
        sleep(1500);
        let doc = browser.html();
        let box = doc.select("#content-container > .contentbox");
        if (box.text().length > 100 && box.text().indexOf('Đang tải') === -1) {
            doc.select("i[hd], .ads, script, style").remove();
            content = box.html();
            break;
        }
        retry++;
    }
    browser.close();

    if (!content) return Response.error("Lỗi tải nội dung chương");

    // Bảng mã giải mã font đặc thù của STV
    const map = {
        'Ғ': 'C', 'Ҕ': 'H', 'ҕ': 'g', 'Җ': 'D', 'җ': 'y', 'Ҙ': 'n', 'ҙ': 'm', 
        'Қ': 'M', 'қ': 'c', 'Ҝ': 'O', 'ҝ': 'W', 'Ҟ': 'T', 'ҟ': 'w', 'Ҡ': 'B', 
        'ҡ': 'A', 'Ң': 'G', 'ң': 'Z', 'Ҥ': 'Q', 'ҥ': 'v', 'Ҧ': 'q', 'ҧ': 'V', 
        'Ҩ': 'o', 'ҩ': 'f', 'Ҫ': 'F', 'ҫ': 'Y', 'Ҭ': 'J', 'ҭ': 'l', 'Ү': 'k', 
        'ү': 'X', 'Ұ': 's', 'ұ': 'L', 'Ҳ': 'x', 'ҳ': 'h', 'Ҵ': 'E', 'ҵ': 'K', 
        'Ҷ': 'a', 'ҷ': 'R', 'Ҹ': 'S', 'ҹ': 'b'
    };

    let decoded = content;
    for (let key in map) {
        decoded = decoded.replace(new RegExp(key, 'g'), map[key]);
    }

    return Response.success(decoded);
}