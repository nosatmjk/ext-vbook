function execute(url) {
    let urlPart = url.split("----/----");
    let browser = Engine.newBrowser();
    browser.launch(urlPart[0], 5000);

    // Click vào đúng số thứ tự chương đã lấy từ TOC
    browser.callJs("document.getElementsByClassName('listchapitem')[" + urlPart[1] + "].click();", 1000);
    
    let content = "";
    let retry = 0;
    while (retry < 10) {
        let doc = browser.html();
        let box = doc.select("#content-container > .contentbox");
        if (box.text().length > 100 && box.text().indexOf('Đang tải') === -1) {
            doc.select("i[hd], .ads, script").remove();
            content = box.html();
            break;
        }
        sleep(1000);
        retry++;
    }
    browser.close();

    // Bảng mã giải mã font chữ STV (Cập nhật từ file của bạn)
    const map = {
        'Ғ': 'C', 'Ҕ': 'H', 'ҕ': 'g', 'Җ': 'D', 'җ': 'y', 'Ң': 'G', 'ң': 'Z', 
        'Ҳ': 'x', 'ҳ': 'h', 'Ҷ': 'a', 'ҷ': 'R', 'Ҹ': 'S', 'ҹ': 'b'
    };

    let decoded = content;
    for (let key in map) {
        decoded = decoded.split(key).join(map[key]);
    }

    return Response.success(decoded);
}