function execute(url) {
    if (url.indexOf("----/----") === -1) {
        // URL thường - đọc trực tiếp
        return readNormalChapter(url);
    } else {
        // URL dạng đặc biệt - cần click vào chương
        return readSpecialChapter(url);
    }
}

function readNormalChapter(url) {
    if (!url.endsWith('/')) url = url + '/';
    
    let browser = Engine.newBrowser();
    browser.launchAsync(url);
    browser.waitUrl(".*?index.php.*?sajax=readchapter.*?", 8000);
    
    let content = waitForContent(browser);
    browser.close();
    
    return processContent(content);
}

function readSpecialChapter(url) {
    let parts = url.split("----/----");
    let bookUrl = parts[0];
    let chapIndex = parseInt(parts[1]);
    
    let browser = Engine.newBrowser();
    browser.launchAsync(bookUrl);
    
    // Đợi và click vào chương
    let success = waitAndClickChapter(browser, chapIndex);
    if (!success) {
        browser.close();
        return Response.error("Không thể tải chương");
    }
    
    let content = waitForContent(browser);
    browser.close();
    
    return processContent(content);
}

function waitForContent(browser) {
    let maxRetry = 8;
    let retry = 0;
    
    while (retry < maxRetry) {
        sleep(1500);
        let doc = browser.html();
        let text = doc.select("#content-container > .contentbox").text();
        
        if (!text.includes('Đang tải nội dung chương')) {
            doc.select("i[hd]").remove();
            return doc.select("#content-container > .contentbox").html();
        }
        retry++;
    }
    
    return '';
}

function waitAndClickChapter(browser, chapIndex) {
    let maxRetry = 8;
    let retry = 0;
    
    // Đợi container chương hiện ra
    while (retry < maxRetry) {
        sleep(1500);
        let doc = browser.html();
        if (doc.select("#chaptercontainerinner").length > 0) {
            browser.callJs("document.getElementById('chaptercontainerinner').scrollIntoView();", 500);
            break;
        }
        retry++;
    }
    
    // Đợi danh sách chương và click
    retry = 0;
    while (retry < maxRetry) {
        sleep(1500);
        let doc = browser.html();
        let chapters = doc.select("a.listchapitem");
        
        if (chapters.length > chapIndex) {
            browser.callJs("document.getElementsByClassName('listchapitem')[" + chapIndex + "].click()", 500);
            return true;
        }
        retry++;
    }
    
    return false;
}

function processContent(html) {
    if (!html) return Response.error("Không có nội dung");
    
    // Bảng giải mã ký tự
    let charMap = {
        'Ҋ': 'U', 'ҋ': 'p', 'Ҍ': 'N', 'ҍ': 'e', 'Ҏ': 'd', 'ҏ': 'u', 'Ґ': 'P', 'ґ': 'z',
        'Ғ': 'j', 'ғ': 'C', 'Ҕ': 'H', 'ҕ': 'g', 'Җ': 'D', 'җ': 'y', 'Ҙ': 'n', 'ҙ': 'm',
        'Қ': 'M', 'қ': 'c', 'Ҝ': 'O', 'ҝ': 'W', 'Ҟ': 'T', 'ҟ': 'w', 'Ҡ': 'B', 'ҡ': 'A',
        'Ң': 'G', 'ң': 'Z', 'Ҥ': 'Q', 'ҥ': 'v', 'Ҧ': 'q', 'ҧ': 'V', 'Ҩ': 'o', 'ҩ': 'f',
        'Ҫ': 'F', 'ҫ': 'Y', 'Ҭ': 'J', 'ҭ': 'l', 'Ү': 'k', 'ү': 'X', 'Ұ': 's', 'ұ': 'L',
        'Ҳ': 'x', 'ҳ': 'h', 'Ҵ': 'E', 'ҵ': 'K', 'Ҷ': 'a', 'ҷ': 'R', 'Ҹ': 'S', 'ҹ': 'b'
    };
    
    // Giải mã từng ký tự
    let decoded = '';
    for (let i = 0; i < html.length; i++) {
        let char = html[i];
        decoded += charMap[char] || char;
    }
    
    // Làm sạch HTML
    let clean = decoded
        .replace(/<p>/g, '')
        .replace(/&lt;p&gt;/g, '')
        .replace(/<i.*?>(.*?)<\/i>/g, '$1')
        .replace(/<span.*?>(.*?)<\/span>(<br>)?/g, '')
        .replace(/<a href=.*?<\/a>/g, '')
        .replace(/ +/g, ' ')
        .replace(/<br>/g, '\n')
        .replace(/\n+/g, '<br>')
        .replace(/\u201c|\u201d/g, '')
        .replace(/&(nbsp|amp|quot|lt|gt|bp|emsp);/g, '');
    
    return Response.success(clean);
}