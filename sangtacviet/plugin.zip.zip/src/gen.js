function execute(url, page) {
    if (!page) page = '1';
    let response = fetch(url + '&p=' + page);
    
    if (response.ok) {
        let doc = response.html();
        let next = doc.select(".pagination li.active + li").text();
        let books = doc.select("#searchviewdiv a.booksearch");
        let data = [];
        
        books.forEach(book => {
            let img = book.select("img").first().attr("src");
            if (img.startsWith('//')) {
                img = 'https:' + img;
            }
            
            data.push({
                name: capitalize(book.select(".searchbooktitle").first().text()),
                link: book.select("a").first().attr("href"),
                cover: img,
                description: book.select(".searchtag").first().text(),
                host: "https://sangtacviet.pro"
            });
        });
        
        return Response.success(data, next);
    }
    return null;
}

function capitalize(sentence) {
    if (!sentence) return '';
    return sentence.split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}