function execute(key, page) {
    if (!page) page = '1';
    let url = 'https://sangtacviet.pro/?find=&findinname=' + encodeURIComponent(key) + '&minc=0&tag=&p=' + page;
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        let next = doc.select(".pagination li.active + li").text();
        let books = doc.select("#searchviewdiv a.booksearch");
        let data = [];
        
        books.forEach(book => {
            data.push({
                name: capitalize(book.select(".searchbooktitle").first().text()),
                link: book.select("a").first().attr("href"),
                cover: book.select("img").first().attr("src"),
                description: book.select("div > span.searchtag").last().text(),
                host: "https://sangtacviet.pro"
            });
        });
        
        return Response.success(data, next);
    }
    return null;
}

function capitalize(sentence) {
    if (!sentence) return '';
    return sentence.split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}