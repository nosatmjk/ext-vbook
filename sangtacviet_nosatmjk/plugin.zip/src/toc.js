load("config.js");

function execute(url) {
    // Parse URL để lấy host và bookid
    // Format: /truyen/{host}/1/{bookid}/
    const regex = /truyen\/([^\/]+)\/\d+\/(\d+)\/?/;
    let match = url.match(regex);
    
    if (!match) return null;
    
    let host = match[1];
    let bookId = match[2];
    
    // Gọi API lấy danh sách chương
    let apiUrl = URL_STV + "/index.php?ngmar=chapterlist&sajax=getchapterlist&h=" + host + "&bookid=" + bookId;
    
    let response = fetch(apiUrl, {
        method: "GET",
        headers: {
            "x-stv-transport": "web",
            "user-agent": "Mozilla/5.0 (Linux; Android 7.1.2; M2101K7BG Build/N2G47H; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/81.0.4044.117 Mobile Safari/537.36",
            "referer": "https://sangtacviet.app/app.v2.php"
        }
    });
    
    if (!response.ok) return null;
    
    try {
        let json = response.json();
        if (!json.data) return null;
        
        let chapters = [];
        let chapterList = json.data.split('-//-');
        
        // Regex để parse từng chương: 1-/-{chapterId}-/-{chapterName}
        const chapterRegex = /1-\/-(\d+)-\/-([^\/]+)/;
        
        chapterList.forEach(item => {
            let chapterMatch = item.match(chapterRegex);
            if (chapterMatch) {
                chapters.push({
                    name: chapterMatch[2],
                    url: "/?bookid=" + bookId + "&c=" + chapterMatch[1] + "&h=" + host,
                    host: URL_STV
                });
            }
        });
        
        return Response.success(chapters);
        
    } catch (error) {
        console.log("Lỗi parse toc: " + error);
        return null;
    }
}