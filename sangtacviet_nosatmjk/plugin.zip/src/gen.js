load("config.js");

function execute(url, page) {
    if (!page) page = '1';
    
    // Xử lý URL đầu vào
    let apiUrl = URL_STV + "/io/searchtp/searchBooks?find=&minc=0&sort=" + url + "&p=" + page + "&tag=";
    
    let response = fetch(apiUrl);
    if (response.ok) {
        let doc = response.html();
        let next = doc.select(".pagination li.active + li").text();
        let books = doc.select("a.booksearch");
        let data = [];
        
        books.forEach(book => {
            let img = book.select("img").first().attr("src");
            if (img.startsWith('//')) {
                img = 'https:' + img;
            }
            
            data.push({
                name: capitalize(book.select(".searchbooktitle").first().text()),
                link: book.select("a").first().attr("href"),
                cover: img,
                description: book.select(".searchtag").first().text(),
                host: URL_STV
            });
        });
        
        return Response.success(data, next);
    }
    return null;
}

function capitalize(sentence) {
    if (!sentence) return '';
    return sentence.split(" ")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}