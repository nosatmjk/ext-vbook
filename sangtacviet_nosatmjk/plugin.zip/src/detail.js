load("config.js");

function execute(url) {
    // Đảm bảo URL có dấu / ở cuối
    if (!url.endsWith('/')) url = url + '/';
    
    let response = fetch(url);
    if (!response.ok) return null;
    
    let text = response.text();
    
    // Regex để lấy object bookinfo từ JavaScript
    const regex = /var\s+bookinfo\s*=\s*(\{[\s\S]*?\});/;
    let match = text.match(regex);
    
    if (!match) return null;
    
    try {
        let bookInfo = JSON.parse(match[1]);
        let doc = Html.parse(text);
        
        // Lấy mô tả
        let description = doc.select(".blk:has(.fa-water) .blk-body").html() || "";
        
        // Lấy thông tin chi tiết
        let details = [];
        doc.select(".blk-body.ib-100").forEach(e => {
            details.push(e.text());
        });
        let detailText = details.join("<br>");
        
        // Xử lý ảnh bìa
        let cover = bookInfo.thumb || "";
        if (cover.startsWith('//')) cover = 'https:' + cover;
        
        return Response.success({
            name: bookInfo.name || bookInfo.namevi || "Không có tên",
            cover: cover,
            author: bookInfo.author || 'Unknown',
            description: description,
            detail: detailText,
            ongoing: true,
            host: URL_STV
        });
        
    } catch (error) {
        console.log("Lỗi parse detail: " + error);
        return null;
    }
}